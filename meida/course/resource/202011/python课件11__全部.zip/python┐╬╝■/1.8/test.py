import datetime
str = '今天是'
d = datetime.datetime.now()
print(d.weekday())
if d.weekday()==0:
    str += '星期一'
elif d.weekday()==1:
    str += '星期二'
elif d.weekday()==2:
    str += '星期三'
elif d.weekday()==3:
    str += '星期四'
elif d.weekday()==4:
    str += '星期五'
elif d.weekday()==5:
    str += '星期六'
else:
    str += '星期日'
print(str)
