1.
username=input('请输入一个用户名：')
password=input('请输入一个密码：')
print(username,password)

#键盘输入2个整数，求和，差，商，余
a=int(input('输入第一个整数'))
b=int(input('输入第二个整数'))
print(a+b)
print(a-b)
print(a/b)
print(a%b)





#输入一个4位数1234变成4321 (反转）
a=input('请输入一个四位数')
result=a[::-1]
print(result)





#输入一个4位数让他从小到大排序   比如 9658 -----  5689  
a=input('请输入一个四位数')
b=sorted(a)
print(b)




#输入你的个人信息，并求出你的身份证的位数，并打印出来
a=input("请输入你的名字")
b=input("请输入你的年龄")
c=input("请输入你的性别")
d=input("身份证号")
print(len(d))    #（len求身份证有几位数）
print(a,b,c,d)






#输入2个数，求 和  差  乘积  商
a=float(input("请输入第一个数"))
b=float(input("请输入第二个数"))
#      1print中可以有任意数据类型的多个内容，彼此间用逗号隔开
print("和是",a+b)
print("差是",a-b)
print("积是",a*b)
print("商是",a/b)
#   2整合在一起      int---%d %i      float--%f默认保留6为小数，不过补0，超过
#四舍五入             string--  %s

print("和是%i\n差是%i\n积是%i\n商是%i"%(a+b,a-b,a*b,a/b))


#i姓名  张山   性别  男     年龄 90  
print("%s%s%s"%('姓名:张山','性别:男','年龄:90'))
print("%s%i"%('姓名:张山性别:男年龄:',90))
print("姓名:张山性别:男年龄:%i"%(90))



#username=input("请输入一个用户名：")
#password=input("请输入一个密码：")


for z in range(1,10):
    for s in range(1,z+1):
        print("%d*%d=%d\t"%(z,s,z*s),end='')
    print()
        
 
 



for i in rnage(1,10):
    for s in range(1,i+1):
        print("%d*%d=%d\%t"%(i,s,i*s),end='')
    print()


















