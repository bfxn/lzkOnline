## json模块

`json`模块用于使用`JSON`序列化和反序列化对象.

`JSON`是JavaScript Object Notation的简写, 也叫 JavaScript 对象符号.

### 1 json语法格式

JSON 是一种轻量级的数据交换格式, 起源于JavaScript 的对象字面量形式, 但是严格上来说 JSON 并不能看成是JavaScript 对象的子集.

JSON 中主要有两种数据类型:json 对象`{}`和 json 数组`[]`.

------

#### `json` 对象

用大括号`{}`括起来, 大括号中是`key:value`形式的数据, 不同的键值对用`,`分开.  

类似于我们 python 中的字典(`dict`).

**下面就是一个 `json` 对象.**

```javascript
{
    "name": "lisi",
    "age" : 20
}
```

**注意:**

1. 键和值中, 如果是字符串则一定要用双引号括起来.(单引号也可以, 但是双引号在各个平台和编程语言中兼容性更好)
2. 如果是整数, 则不需要使用双引号.
3. `key`一般使用字符串, `value`可以是任意类型(字符串, json 数组, json 对象都可以).

------

#### `json`数组

使用`[]`括起来, 存储的数据可以是字符串, 数字, 和 `json` 对象.  

类似于我们 python 中的列表(`list`)
**
下面就是一个`json`数组**

```javascript
[
    {    
        "name":"lisi",    # name --> 用户名
        "age" : 20        # age ---> 用户使用年限
    
    },
    {
        "name" : "zs",
        "age" : 30    
    }
]
```

**`json`数组中可以存储字符串类型**

```python
["a", "b", "c"]
```



### 2 json模块基本使用

对 json 一般有两种操**作:序列化(编码)和反序列化(解码).**

序列化是指, 把 python 对象转变成 json 格式的数据, 并保存.

反序列化是指, 把 json 格式的数据转变成 python 对象.

------

#### json 数据类型和 python 数据类型对应关系

**注意:**

_括号中的类型表示可以把 python 中的类型转换成 JSON 类型, 但是不能从 JSON 类型转换成 python 类型_

| JSON 类型 |       python 类型       |
| :-----: | :-------------------: |
| object  |         dict          |
|  array  |     list\(tuple\)     |
| string  | unicode\(str, bytes\) |
| number  |      int, float       |
|  true   |         True          |
|  false  |         False         |
|  null   |         None          |

**说明:**

对于字符串数据, 应该假设使用的是 Unicode 字符串. 如果在编码时遇到字节字符串, 则默认使用`utf-8`将其解码为 Unicode 的字符串. 解码是, JSON 字符串总是以 Unicode 的形式返回.

------

#### 序列化操作1:`json.dump(obj, f, **opts)`

将`obj`序列化到文件对象`f`中.

`opts`表示关键字参数的集合(多个关键字参数),可以通过这些参数来控制序列化的流程, 这些关键字参数都是可选的.

```python
import json

d = {
    "name": "zs",
    "age": 30,
    "girls": ["志玲", "凤姐"]
}
json.dump(d, open("data.json", mode="w+"))
```

<img src="http://o7cqr8cfk.bkt.clouddn.com/markdown/1500804156483.png">

------

##### 关键字参数说明

|    关键字参数     |                    说明                    |
| :----------: | :--------------------------------------: |
|   skipkeys   | 布尔标志.当字典的`key`不是基本类型(`str, int, float, bool, None`)时的处理方式.  `True`就跳过这个`key-value`, `False`(默认值)就抛一个异常`TypeError` |
| ensure_ascii | 布尔标志. 如果是`True`(默认值), 则会把所有的非`ascii`字符进行转义处理, 如果是`False`则会把所有字符原样输出.要保证你的文件支持非`ascii`字符 |
| check_circle | 布尔标志. 确定检测容器的循环引用. 默认值是`True`, 如果设置为`False`, 则不检测, 一旦出现了循环引用则会抛出异常`OverflowEerror`, 或者更糟 |
|  allow_nan   | 布尔标志. 确定是否序列化范围外的浮点数.(`nan, inf, -inf`). 默认值是`True`. 如果是`False`, 则当序列化的值中有上面的值是会抛出异常`ValueError` |
|    indent    | 一个非负整数. 表示在打印数组和对象的时候的缩进量(空格的个数). 默认是`None`, 表示没有缩进, 用最紧凑的方式显示.  如果是`0或负数或""`则只换行,不缩进. 如果是个字符串, 则用这个字符串来缩进. 比如用:`\t` |
|  separators  | 一个元组.`(item_separator, key_separator)`, `item_separator`是指的数组元素之间的分隔符, `key_separator`是指的`key 与 value`之间的分隔符. 默认是:`(",", ":")`. 永远不要更改默认值 |
|   default    | 一个函数. 如果某个`value`是 json 不支持的类型, 则使用这个函数的返回值来替换`value`. python 会把那个不支持的类型的数据作为参数传递到这个函数中. |
|   sort_key   |    布尔值. 表示是否对字典的`key`进行排序.默认值`False`     |

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json

d = {
    "name": "zs",
    "age": 30,
    "girls": ["志玲", "凤姐"],
    "a": float("1"),
    "b": lambda : 2
}
json.dump(d, open("data.json", mode="w+", encoding="utf-8"),
          ensure_ascii=False,
          allow_nan=True,
          indent=2,
          separators=(",", ":"),
          default=lambda a: "abc",
          sort_keys=True)
print(int("1"))
```

![](http://o7cqr8cfk.bkt.clouddn.com/17-7-23/57456351.jpg)

------

#### 序列化操作2:`json.dumps(obj, **opts)`

和`json.dump()`类似, 只是这个函数是把序列化后的字符串以返回值的形式返回了.

------

#### 反序列化操作1:`json.load(f, **opts)`

从文件反序列化JSON.

`f`文件对象.

`opts`表示关键字参数的集合(多个关键字参数),可以通过这些参数来控制反序列化的流程, 这些关键字参数都是可选的.

```python
import json

with open("data.json", mode="r+", encoding="utf-8") as f:
    obj = json.load(f)
    print(obj)
```

<img src="http://o7cqr8cfk.bkt.clouddn.com/markdown/1500815081203.png">

##### 关键字参数说明

|     关键字参数      |                    说明                    |
| :------------: | :--------------------------------------: |
|  object_hook   |  一个函数. 解析JSON 对象的时候调用的函数. 默认使用`dict()`   |
|  parse_float   |     一个函数. 解析浮点数的时候使用. 默认使用`float()`      |
|   parse_int    |       一个函数. 解析整数的时候使用. 默认使用`int()`       |
| parse_constant | 一个函数. 解析常数的时候使用. 像`-Infinity, Infinity, NaN, true, false` |

------

#### 反序列化操作2:`json.loads(s, * *opts)`

与`json.load(f, **opts)`类似, 只是这个函数是从JSON 格式的字符串中反序列化数据.





