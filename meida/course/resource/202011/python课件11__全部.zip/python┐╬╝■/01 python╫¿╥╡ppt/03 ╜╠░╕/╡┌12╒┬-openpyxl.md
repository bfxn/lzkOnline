# openpyxl

​	openpyxl模块是一个读写Excel 2010文档的Python库，如果要处理更早格式的Excel文档，需要用到额外的库，openpyxl是一个比较综合的工具，能够同时读取和修改Excel文档。 

##1.	安装openpyxl模块

>  pip3 install openpyxl
>
> 或者
>
> 在pycharm中直接安装

##2.	openpyxl的基本用法

​	想要操作Excel首先要了解Excel 基本概念，Excel中列以字幕命名，行以数字命名，比如左上角第一个单元格的坐标为A1，下面的为A2，右边的B1。

​	openpyxl中有三个不同层次的类，Workbook是对工作簿的抽象，Worksheet是对表格的抽象，Cell是对单元格的抽象，每一个类都包含了许多属性和方法。	

> 操作Excel的一般场景:
>
> ```
> 打开或者创建一个Excel需要创建一个Workbook对象
> 获取一个表则需要先创建一个Workbook对象，然后使用该对象的方法来得到一个Worksheet对象
> 如果要获取表中的数据，那么得到Worksheet对象以后再从中获取代表单元格的Cell对象
> ```

####2.1	Workbook对象

​	一个Workbook对象代表一个Excel文档，因此在操作Excel之前，都应该先创建一个Workbook对象。对于创建一个新的Excel文档，直接进行Workbook类的调用即可，对于一个已经存在的Excel文档，可以使用openpyxl模块的load_workbook函数进行读取，该函数包涵多个参数，但只有filename参数为必传参数。filename 是一个文件名，也可以是一个打开的文件对象。

```python
import openpyxl
excel = openpyxl.Workbook()  # 创建本地工作簿
excel = openpyxl.load_workbook("abc.xlsx")  # 加载本地已存在的工作簿
# 操作工作簿完毕后需要保存工作簿
excel.save("hello.xlsx")
```

PS：Workbook和load_workbook相同，返回的都是一个Workbook对象。

Workbook对象提供了很多属性和方法，其中，大部分方法都与sheet有关，部分属性如下：

```python
# 属性 attribute
excel.active # 获取当前活跃的Worksheet对象
excel.worksheets # 以列表的形式返回所有的Worksheet对象
excel.sheetnames # 获取工作簿中的表名[name1, name2, name3]
excel.encoding # 获取文档的字符集编码
excel.properties # 获取文档的元数据，如标题，创建者，创建日期等

# 通过索引值设置当前活跃的worksheet
excel.active = 0
```

```python
# 可以通过工作表名获取到worksheet对象
excel_sheet = excel["Sheet1"]e
```

``````python
# 工作表的创建和删除
excel.remove(excel_sheet) # 删除一个表格，参数为worksheet对象
# excel.remove_sheet()已被废弃sh
excel.create_sheet() # 创建一个空的表格，参数为表名和index
``````

####2.2	Worksheet对象

​	有了Worksheet对象以后，我们可以通过这个Worksheet对象获取表格的属性，得到单元格中的数据，修改表格中的内容。openpyxl提供了非常灵活的方式来访问表格中的单元格和数据，常用的Worksheet属性如下：

```python
# 属性 attribute
excel_sheet.title # 表格的标题(可读可写)
excel_sheet.dimensions # 表格的大小，这里的大小是指含有数据的表格的大小，即：左上角的坐标:右下角的坐标

excel_sheet.max_row # 表格的最大行数
excel_sheet.min_row # 表格的最小行数
excel_sheet.max_column # 表格的最大列数
excel_sheet.min_column # 表格的最小列数
excel_sheet.rows # 按行获取单元格(Cell对象) - 生成器
excel_sheet.columns # 按列获取单元格(Cell对象) - 生成器
excel_sheet.values # 按行获取表格的内容(数据)  - 生成器
```

``````python
# 方法
excel_sheet.iter_rows() # 按行获取所有单元格，内置属性有(min_row,max_row,min_col,max_col)
excel_sheet.iter_cols() # 按列获取所有的单元格

# 通过key值获取
excel_sheet["A"]  # 返回A列中所有的单元格cell对象
excel_sheet["1"]  # 返回第一行中所有的单元格cell对象
excel_sheet["A1"] # 返回该单元格对象
``````

```python
for row in excel2[‘abc‘].iter_rows(min_row=2,max_row=4,min_col=2,max_col=4):
    print(row)

(<Cell ‘abc‘.B2>, <Cell ‘abc‘.C2>, <Cell "abc".D2>)
(<Cell ‘abc‘.B3>, <Cell ‘abc‘.C3>, <Cell "abc".D3>)
(<Cell ‘abc‘.B4>, <Cell ‘abc‘.C4>, <Cell "abc".D4>)
```

#### 2.3	Cell

​	Cell对象比较简单，常用的属性如下:

```python
# 属性
row # 单元格所在的行
column # 单元格坐在的列
value # 单元格的值
coordinate # 单元格的坐标
```

```python
>>> excel2[‘abc‘].cell(row=1,column=2).coordinate
‘B1
>>> excel2[‘abc‘].cell(row=1,column=2).value
‘test‘
>>> excel2[‘abc‘].cell(row=1,column=2).row
1
>>> excel2[‘abc‘].cell(row=1,column=2).column
‘B‘
·
```