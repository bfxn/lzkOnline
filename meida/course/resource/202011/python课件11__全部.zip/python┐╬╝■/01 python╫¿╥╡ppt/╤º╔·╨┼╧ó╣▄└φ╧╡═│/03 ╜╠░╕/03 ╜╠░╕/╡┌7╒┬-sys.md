python 自称 "Batteries included"(自带电池, 自备干粮?), 就是因为他提供了很多内置的模块, 使用这些模块无需安装和配置即可使用.

本章主要介绍 python 的一些内置常用核心模块

# Python 常用的核心模块

## sys模块

<u>`sys`模块模块包括了一些针对特定系统的功能</u>。

使用`sys`首先需要导入`sys`模块

```python
import sys
```

------

###2.1 `sys.argv`: 接收命令行参数

我们运行脚本的的时候, 可以传递一个参数过去, 参数的参数被存储在`sys.argv`中.

返回的是个列表, 第一个参数总是这个文件名, 然后才是依次传入的参数, 所有的参数都是作为字符串存储的.

```python
import sys

print(sys.argv)
```

<img src="http://o7cqr8cfk.bkt.clouddn.com/markdown/1499996628769.png">

------

# `sys.exit()`: 退出 python 程序

```python
import sys

print("你好")
sys.exit()  # 程序退出
print("你坏")  # 没有机会执行
```

可以传整数参数: 0 表示正常退出, 其他整数表示非正常退出.

------

### 2.2 <u>`sys.path`: 模块的搜索路径</u>

获取指定模块搜索路径的字符串集合，可以将写好的模块放在得到的某个路径下，就可以在程序中import时正确找到。

```python
import sys


def print_path():
    for x in sys.path:
        print(x)
    
    print("----华丽的分割线----")


print_path()
sys.path.append("/Users/lzc/a")    # 添加自己的路径

print_path()
```

<img src="http://o7cqr8cfk.bkt.clouddn.com/markdown/1499997343392.png">

------

### 2.3 `sys.moudles`:<u>记录已经加载的模块</u>

是一个全局字典，该字典是python启动后就加载在内存中。每当程序员导入新的模块，sys.modules将自动记录该模块。当第二次再导入该模块时，python会直接到字典中查找，从而加快了程序运行的速度。它拥有字典所拥有的一切方法。

```python
import sys

for k in sys.modules:
    print(k)
```

<img src="http://o7cqr8cfk.bkt.clouddn.com/markdown/1499998391159.png">





