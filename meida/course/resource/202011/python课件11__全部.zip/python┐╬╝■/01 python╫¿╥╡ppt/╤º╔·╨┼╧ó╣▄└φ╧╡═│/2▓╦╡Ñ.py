#学生管理系统


#1.输出功能选项
print("-"*30)
print("   python版学生管理系统")
print("1 添加学生信息")
print("2 删除学生信息")
print("3 修改学生的信息")
print("4 查询学生信息")
print("5 退出系统")
print("-"*30)


#2.等待用户进行选择
a = int(input("请输入您选择的数字:"))

#3.根据用户的选择执行相应的事情
if a == 1:
    pass
elif a==2:
    pass
elif a==3:
    pass
elif a==4:
    pass
elif a==5:
    pass
