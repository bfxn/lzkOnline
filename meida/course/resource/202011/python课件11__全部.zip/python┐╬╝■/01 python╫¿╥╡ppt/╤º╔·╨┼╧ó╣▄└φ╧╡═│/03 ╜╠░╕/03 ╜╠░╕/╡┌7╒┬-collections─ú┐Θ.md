## 一、collections模块

**这是个有用的容器模块, 提供了许多有用的集合,** 来弥补通用的内置容器:`list, dict, tuple, set`

![](images/7-3-1.png)



### 1.1 namedtuple()

`namedtuple()`是一个工厂函数, 用来创建一个`tuple`的子类型`namedtuple`.

我们以前的`tuple`只能通过下标去访问, `namedtuple`访问元素的时候可以使用类似属性的东西去访问.

------

#### 基本使用

```python
from collections import namedtuple

# 参数1: 要创建的 tuple 的类型的名字 参数2:新类型拥有的属性列表
# 返回的是个类, 这个类的类名就是 Point(参数1确定的) , 拥有两个属性 x, y
# 变量 Point 只是表示我们又重新定义了变量指向了返回的那个类而已
Point = namedtuple("Point", ["x", "y"])
print(Point)
print(issubclass(Point, tuple))  # 确实是 tuple 的子类

# 使用返回的类型创建一个对象, 这个对象就表示一个平面中的点
p1 = Point(x=10, y=20)
print(p1.x)
print(p1.y)
```

![](images/7-3-2.png)

**说明:**

1. 从上面可以很容易的看出来, 使用`namedtuple`可以很容易定义出一种数据类型
2. 他具备`tuple`的不可变性, 又能根据属性来引用, 一个字:用起来就是爽
3. 定义一个表示平面的圆: `Circle = namedtuple('Circle', ['x', 'y', 'r'])`

#### 继承自`tuple`

由于`namedtuple`返回的类继承自`tuple`, 所以`tuple`的属性和方法在这里都可以使用.

比如用下标去访问, 用`for`去迭代等等.

```python
from collections import namedtuple

Point = namedtuple("Point", ["x", "y"])
p1 = Point(x=10, y=20)

print(p1[0])
print(p1[1])

for i in p1:
    print(i)
```

![](images/7-3-3.png)

#### 3 个新增方法和 2 个新增属性

##### 类方法:`_make(序列或迭代器)`

从已知的序列或迭代器中创建一个实例

```python
from collections import namedtuple

Point = namedtuple("Point", ["x", "y"])

nums = [20, 100]
p1 = Point._make(nums)
print(p1)

p2 = Point._make(range(10, 12))
print(p2)
```

![](images/7-3-4.png)

------

##### 实例方法:`_asdict()`

返回一个列表(从3.1f开始是一个`OrderedDict`)

```python
from collections import namedtuple

Point = namedtuple("Point", ["x", "y"])
p1 = Point(10, 20)
d = p1._asdict()
print(d)
```

![](images/7-3-5.png)

------

##### 实例方法:`_replace(关键字参数)`

更改某个属性的值, 由于`namedtuple`是不可变的, 所以返回的是一个新的`namedtuple`实例对象

```python
from collections import namedtuple

Point = namedtuple("Point", ["x", "y"])
p1 = Point(10, 20)
p2 = p1._replace(y=100)
print(p2)
```

![](images/7-3-6.png)

------

##### 类属性:`_source`

返回创建的类的源码

##### 类属性: `_fields`

返回创建类的所有属性

```python
from collections import namedtuple

Point = namedtuple("Point", ["x", "y"])
print(Point._fields)
```

![](images/7-3-7.png)



### 1.2 类：deque



`deque`是一个双向队列.

发音: deck  是 "double-ended queue" 的简写

`deque`线程安全, 内存高效, 支持在两端添加和删除元素.

相对`list`主要体现在添加和删除效率比较高.

------

#### 创建`deque`对象

`deque([iterable[, maxlen]])`
两个参数都是可选
参数1: 可迭代对象, 会把里面的数据初始近双端队列中
参数2: 双端队列允许的最大长度. 如果元素个数超出了这个只, 则只保留后面添加的.

```python
from collections import deque

d = deque(range(10))
print(d)
```

![](images/7-3-8.png)

------

#### 方法和属性

##### `append(x)`

队列的右边添加元素.
注意:对队列来说, 左边指队首, 右边指队尾

##### `appendleft(x)`

在队列的左边添加元素

##### `clear()`

情况队列中的所有元素, 然后长度成为 0 

##### `copy()`

浅复制队列中的元素 (3.5新增)

##### `count(x)`

统计指定的元素 `x` 在队里中出现的次数

##### `extend(iterable)`

向右扩展队列

##### `extendleft(iterable)`

向左扩展队列

##### `index(x)`

查找`x`在队里中第一次出现的下标. 如果没有找到, 则抛出异常

##### `insert(i, x)`

把`x`插入到下标为`i`的位置

##### `pop()`

删除并返回最右边的元素

##### `popleft`

删除并返回最左边的元素

##### `remove(x)`

删除队列中第一个`x`

##### `reverse()`

翻转队列中的元素

##### 只读属性:`maxlen`

创建队列的时候设定的允许的元素的最大个数



### 1.3 类：Counter

`Counter`<u>用来统计集合中元素出现的次数</u>.

`Counter`是`dict`的子类, 每个键值对都表示元素和元素出现的次数.

#### 创建`Counter`对象

`Counter([iterable-or-mapping])`

参数:需要统计的迭代类型或mapping 类型

```python
from collections import Counter

# 通过可迭代类型创建一个 Counter
c1 = Counter("abcabc3344efg")

print(c1)

# 通过 dict 创建一个 Counter
c2 = Counter({"a": 3, "b": 4})    # 表示 a 出现了3次
print(c2)

# 通过关键字创建一个 Counter
c3 = Counter(cats=4, dogs=8)    # 表示 cats 出现了4次
print(c3)
```

![](images/7-3-9.png)

------

#### 有用的几个方法

##### `elements()`

根据统计结果, 返回一个包含所有元素的可迭代类型的对象

##### `most_common(n)`

返回出现次数最多的前`n`个元素

```python
from collections import Counter

c1 = Counter("abcabc3344efg")
print(sorted(c1.elements()))    # 所有的元素
print(c1.most_common(2))

c2 = Counter({"a": 3, "b": 4})
print(sorted(c2.elements()))
print(c2.most_common(2))

c3 = Counter(cats=4, dogs=8)
print(sorted(c3.elements()))
print(c3.most_common(1))
```



### 1.4 类：defaultdict

在以前我们使用`dict`的时候, 如果访问不存在的`key`时会抛出异常. 使用`defaultdict`则可以避免这个问题.

`defaultdict(函数)`

说明: 

1. 如果访问的`key`不存在, 则会调用传递的函数, 把函数作为`value`
2. 其余的使用和`dict`一样

```python
from collections import defaultdict

d = defaultdict(lambda: "默认值")
d["b"] = "bbb"
# key 不存在, 则调用函数, 把函数返回值作为值. 并把键值对存入到 defaultdict中
print(d["a"])    
print(d["b"])
print(d)
```

![](images/7-3-11.png)

------

```python
from collections import defaultdict

s = [('yellow', 1), ('blue', 2), ('yellow', 3), ('blue', 4), ('red', 1)]

d = defaultdict(list)
for k, v in s:
    d[k].append(v)
    

print(sorted(d.items()))
```

![](images/7-3-12.png)

------

```python
from collections import defaultdict
# 统计每个字符出现的次数
s = "abcdabAbc"

d = defaultdict(int)
for k in s:
    d[k] += 1
    

print(sorted(d.items()))
```

![](images/7-3-13.png)



### 1.5 类：OrderedDict

`dict`的键值对是无序的.

`ordereddict`是可以记录键值对的插入顺序的`dict`.

```python
from collections import OrderedDict

od = OrderedDict()
od["a"] = 10
od["c"] = 20
od["b"] = 40
for k, v in od.items():
    print(k + " : " + str(v))
```

![](images/7-3-14.png)



