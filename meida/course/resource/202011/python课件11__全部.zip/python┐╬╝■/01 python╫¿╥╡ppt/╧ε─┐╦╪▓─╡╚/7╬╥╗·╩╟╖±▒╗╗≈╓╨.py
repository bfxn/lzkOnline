import pygame
from pygame.locals import *
import time
import random


class HeroPlane:

    def __init__(self, scree):
        self.x = 190
        self.y = 576
        self.scree = scree
        self.image = pygame.image.load("./feiji/hero1.png")
        self.bullet_list = []

    def display(self):
        self.scree.blit(self.image, (self.x, self.y))

        for bullet in self.bullet_list:
            bullet.display()
            bullet.move()

            if bullet.judge():
                self.bullet_list.remove(bullet)

    def move_left(self):
        self.x -= 5

    def move_right(self):
        self.x += 5

    def fire(self):
        self.bullet_list.append(Bullet(self.scree, self.x, self.y))

    # 判断我方战机是否被击中 参数: 敌方战机所有发射的有效子弹列表
    def is_hit(self, bullet_list):
        for bullet in bullet_list:
            if self.x < bullet.x < self.x + 100 and self.y < bullet.y < self.y + 124:
                return True
        return False


class Bullet:

    def __init__(self, scree, x, y):
        self.x = x + 40
        self.y = y - 22
        self.scree = scree
        self.image = pygame.image.load("./feiji/bullet.png")

    def display(self):
        self.scree.blit(self.image, (self.x, self.y))

    def move(self):
        self.y -= 20

    def judge(self):
        if self.y < 0:
            return True
        else:
            return False


class EnemyPlane:

    def __init__(self, scree):
        self.x = 0
        self.y = 0
        self.scree = scree
        self.image = pygame.image.load("./feiji/enemy0.png")
        self.bullet_list = []
        self.direction = "right"

    def display(self):
        self.scree.blit(self.image, (self.x, self.y))

        for bullet in self.bullet_list:
            bullet.display()
            bullet.move()

            if bullet.judge():
                self.bullet_list.remove(bullet)

    def move(self):
        if self.direction == "right":
            self.x += 5
        elif self.direction == "left":
            self.x -= 5

        if self.x >= 480 - 50:
            self.direction = "left"
        if self.x <= 0:
            self.direction = "right"

    def fire(self):
        ran_num = random.randint(1, 100)
        if ran_num == 50 or ran_num == 30:
            self.bullet_list.append(EnemyBullet(self.scree, self.x, self.y))


class EnemyBullet:

    def __init__(self, scree, x, y):
        self.x = x + 25
        self.y = y + 40
        self.scree = scree
        self.image = pygame.image.load("./feiji/bullet1.png")

    def display(self):
        self.scree.blit(self.image, (self.x, self.y))

    def move(self):
        self.y += 20

    def judge(self):
        if self.y > 700:
            return True
        else:
            return False


def key_control(hero):
    for event in pygame.event.get():
        if event.type == QUIT:
            print("exit")
            exit()

        elif event.type == KEYDOWN:
            if event.key == K_a or event.key == K_LEFT:
                print('left')
                hero.move_left()

            elif event.key == K_d or event.key == K_RIGHT:
                print('right')
                hero.move_right()

            elif event.key == K_SPACE:
                print('space')
                hero.fire()


def main():
    scree = pygame.display.set_mode((480, 700), 0, 32)
    background = pygame.image.load("./feiji/background.png")
    hero = HeroPlane(scree)
    enemy = EnemyPlane(scree)
    while True:
        scree.blit(background, (0, 0))
        hero.display()
        enemy.display()
        enemy.move()
        enemy.fire()

        # 调用我方战机的实例方法,判断是否被击中,参数为敌机所有有效子弹列表
        if hero.is_hit(enemy.bullet_list):
            # 被击中
            a += 1
            if a == 5:
                hero.image = pygame.image.load(r".\feiji\hero_blowup_n1.png")
            if a == 10:
                hero.image = pygame.image.load(r".\feiji\hero_blowup_n2.png")
            if a == 15:
                hero.image = pygame.image.load(r".\feiji\hero_blowup_n3.png")
            if a == 20:
                hero.image = pygame.image.load(r".\feiji\hero_blowup_n4.png")

        key_control(hero)

        # 更新需要显示的内容
        pygame.display.update()
        time.sleep(0.05)


if __name__ == '__main__':
    main()