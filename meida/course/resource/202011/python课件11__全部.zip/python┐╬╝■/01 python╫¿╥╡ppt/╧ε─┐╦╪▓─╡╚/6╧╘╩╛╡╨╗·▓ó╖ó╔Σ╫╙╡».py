import pygame
from pygame.locals import *
import time
import random

class HeroPlane:

    def __init__(self, scree):
        self.x = 190
        self.y = 576
        self.scree = scree
        self.image = pygame.image.load("./feiji/hero1.png")
        self.bullet_list = []

    def display(self):
        self.scree.blit(self.image, (self.x, self.y))

        for bullet in self.bullet_list:
            bullet.display()
            bullet.move()

            if bullet.judge():
                self.bullet_list.remove(bullet)

    def move_left(self):
        self.x -= 5

    def move_right(self):
        self.x += 5

    def fire(self):
        self.bullet_list.append(Bullet(self.scree, self.x, self.y))


class Bullet:

    def __init__(self, scree,x ,y):
        self.x = x + 40
        self.y = y - 22
        self.scree = scree
        self.image = pygame.image.load("./feiji/bullet.png")

    def display(self):
        self.scree.blit(self.image, (self.x, self.y))

    def move(self):
        self.y -= 20

    def judge(self):
        if self.y < 0:
            return True
        else:
            return False

# 敌机类：
class EnemyPlane:

    def __init__(self, scree):
        self.x = 0
        self.y = 0
        self.scree = scree
        self.image = pygame.image.load("./feiji/enemy0.png")
        # 表示敌机发射出的子弹
        self.bullet_list = []  # 存储敌机发射出的子弹，用于判断是否击中敌机
        self.direction = "right"  # 该属性，用于控制敌机的方法

    # 用于显示飞机
    def display(self):
        self.scree.blit(self.image, (self.x, self.y))  # 显示敌机

        for bullet in self.bullet_list:
            bullet.display()
            bullet.move()
            # 判断子弹是否超过了边界，
            if bullet.judge():
                self.bullet_list.remove(bullet)

    # 敌机移动
    def move(self):
        if self.direction == "right":
            self.x += 5
        elif self.direction == "left":
            self.x -= 5

        if self.x >= 480 -50:
            self.direction = "left"
        if self.x <= 0:
            self.direction = "right"


    # 敌机机发射子弹
    def fire(self):
        # 产生一个随机数：
        ran_num = random.randint(1,100)
        if ran_num == 50 or ran_num == 30:
            self.bullet_list.append(EnemyBullet(self.scree, self.x, self.y))

# 创建敌机的子弹
class EnemyBullet:

    def __init__(self, scree,x ,y):
        self.x = x + 25
        self.y = y + 40
        self.scree = scree
        self.image = pygame.image.load("./feiji/bullet1.png")

    # 用于显示子弹
    def display(self):
        self.scree.blit(self.image, (self.x, self.y))

    # 子弹向下移动
    def move(self):
        self.y += 20

    # 判断子弹的 y值，是否超越边界
    def judge(self):
        if self.y > 700:
            return True
        else:
            return False

def key_control(hero):
    # 获取事件，比如按键等
    for event in pygame.event.get():

        # 判断是否是点击了退出按钮
        if event.type == QUIT:
            print("exit")
            exit()
        # 判断是否是按下了键
        elif event.type == KEYDOWN:
            # 检测按键是否是a或者left
            if event.key == K_a or event.key == K_LEFT:
                print('left')
                hero.move_left()

            # 检测按键是否是d或者right
            elif event.key == K_d or event.key == K_RIGHT:
                print('right')
                hero.move_right()

            # 检测按键是否是空格键
            elif event.key == K_SPACE:
                print('space')
                hero.fire()  # 我机开火
def main():
    # 1.创建一个窗口，用来显示内容,窗口宽480，高852
    scree = pygame.display.set_mode((480, 700), 0, 32)

    # 2.创建一个和窗口大小的图片，用来当背景图
    background = pygame.image.load("./feiji/background.png")
    # 创建我机
    hero = HeroPlane(scree)
    # 创建敌机
    enemy = EnemyPlane(scree)
    # 3.把背景图放到窗口中显示
    while True:
        # 设定需要显示的背景图
        scree.blit(background, (0, 0))  # 背景图的左上角，和窗口左上角重合
        # 显示我机
        hero.display()
        enemy.display()  # 显示敌机
        enemy.move()  # 敌机移动
        enemy.fire()  # 敌机发射子弹
        key_control(hero)

        # 更新需要显示的内容
        pygame.display.update()

        time.sleep(0.05)


if __name__ == '__main__':
    main()