import pygame
from pygame.locals import *
# 创建类，描述我机
class HeroPlane:

    def __init__(self, scree):
        self.x = 190
        self.y = 576
        self.scree = scree
        self.image = pygame.image.load("./feiji/hero1.png")

    # 用于显示飞机
    def display(self):
        self.scree.blit(self.image, (self.x, self.y))  # 显示我机

    # 飞机左移
    def move_left(self):
        self.x -= 5

    # 飞机右移
    def move_right(self):
        self.x += 5


def key_control(hero):
    # 获取事件，比如按键等
    for event in pygame.event.get():

        # 判断是否是点击了退出按钮
        if event.type == QUIT:
            print("exit")
            exit()
        # 判断是否是按下了键
        elif event.type == KEYDOWN:
            # 检测按键是否是a或者left
            if event.key == K_a or event.key == K_LEFT:
                print('left')
                hero.move_left()

            # 检测按键是否是d或者right
            elif event.key == K_d or event.key == K_RIGHT:
                print('right')
                hero.move_right()

            # 检测按键是否是空格键
            elif event.key == K_SPACE:
                print('space')
def main():
    # 1.创建一个窗口，用来显示内容,窗口宽480，高852
    scree = pygame.display.set_mode((480, 700), 0, 32)

    # 2.创建一个和窗口大小的图片，用来当背景图
    background = pygame.image.load("./feiji/background.png")
    # 创建我机
    hero = HeroPlane(scree)  # 创建对象

    # 3.把背景图放到窗口中显示
    while True:
        # 设定需要显示的背景图
        scree.blit(background, (0, 0))  # 背景图的左上角，和窗口左上角重合
        # 显示我机
        hero.display()  # 对象调用方法
        key_control(hero)

        # 更新需要显示的内容
        pygame.display.update()

if __name__ == '__main__':
    main()