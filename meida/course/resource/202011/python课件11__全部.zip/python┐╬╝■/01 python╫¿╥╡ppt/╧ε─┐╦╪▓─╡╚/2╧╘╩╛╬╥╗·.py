import pygame

def main():
    # 1.创建一个窗口，用来显示内容,窗口宽480，高852
    scree = pygame.display.set_mode((480, 700), 0, 32)
    # 2.创建一个和窗口大小的图片，用来当背景图
    background = pygame.image.load("./feiji/background.png")
    #创建我机
    hero = pygame.image.load("./feiji/hero1.png")
    x = 190
    y = 576
    # 3.把背景图放到窗口中显示
    while True:
        # 设定需要显示的背景图
        scree.blit(background, (0, 0))  # 背景图的左上角，和窗口左上角重合
        #显示我机
        scree.blit(hero,(x,y))
        # 更新需要显示的内容
        pygame.display.update()

if __name__ == '__main__':
    main()
