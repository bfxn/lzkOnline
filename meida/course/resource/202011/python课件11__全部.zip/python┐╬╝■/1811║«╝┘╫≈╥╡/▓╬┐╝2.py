'''
学生信息管理系统
'''
import sys
dict = {'李小花':[18,'高三','1班'],'王二狗':[17,'高二','2班'],'刘三胖':[16,'高一','1班'],'史铁柱':[17,'高二','1班'],'隔壁老王':[18,'高三','2班']}
#展示提示信息
print('**********************************')
print('*	欢迎进入学生信息管理系统	*')
print('*		1.查找学生			    *')
print('*		2.增加学生			    *')
print('*		3.修改学生			    *')
print('*		4.删除学生			    *')
print('*		5.显示全部信息			*')
print('*		6.退出系统			    *')
print('**********************************')
#提示用户输入选项
while True:
    name = int(input('请输入您的选项：'))
    while name == 1:
        a = input('输入学生姓名，可查找学生信息：')
        if a in dict:
            for a,i in dict.items():
                print(a,i)
                break
        else:
            print('您要查找的学生不存在，请重新输入')
            input('按任意键继续')
            continue
#增加学生信息
    if name == 2:
        c = input('请输入你要增加的学生姓名：')
        d = input('请输入您要增加的学生年龄：')
        e = input('请输入您要增加的学生年纪：')
        f = input('请输入你要增加的学生班级：')
        print('通过姓名可以增加学生信息,增加姓名请按1\n增加年龄请按2\n增加年级请按3\n增加班级请按4\n退出请按5')
        b = int(input('请输入您的选项：'))
        if b == 1:
            dict[c]=d,e,f
        elif b == 2:
            dict[c]=d
        elif b == 3:
            dict[c]=e
        elif b == 4:
            dict[c]=f
        elif b == 5:
            break
        else:
            print('您的输入不合法，请重新输入')
            input('按任意键继续')
            continue
#修改学生信息
    elif name == 3:
        c = input('请输入你要修改的学生姓名：')
        d = input('请输入您要修改的学生年龄：')
        e = input('请输入您要修改的学生年纪：')
        f = input('请输入你要修改的学生班级：')
        print('通过姓名可以增加学生信息,修改姓名请按1\n修改年龄请按2\n修改年级请按3\n修改班级请按4\n退出请按5')
        b = int(input('请输入您的选项：'))
        if b == 1:
            dict[c] = c
        elif b == 2:
            dict[c] = d
        elif b == 3:
            dict[c] = e
        elif b == 4:
            dict[c] = f
        elif b == 5:
            break
        else:
            print('您的输入不合法，请重新输入')
            input('按任意键继续')
            continue
#删除学生信息
    elif name == 4:
        c = input('请输入你要删除的学生姓名：')
        d = input('请输入您要删除的学生年龄：')
        e = input('请输入您要删除的学生年纪：')
        f = input('请输入你要删除的学生班级：')
        print('通过姓名可以删除学生信息,删除姓名请按1\n删除年龄请按2\n删除年级请按3\n删除班级请按4\n退出请按5')
        b = int(input('请输入您的选项：'))
        if b == 1:
            del dict[c]
        elif b == 2:
            del dict[d]
        elif b == 3:
            del dict[e]
        elif b == 4:
             del dict[f]
        elif b == 5:
            break
        else:
            print('您的输入不合法，请重新输入')
            input('按任意键继续')
            continue
#展示学生全部信息
    elif name == 5:
        for i,n in dict.items():
            print(i,n)
#退出系统
    elif name == 6:
        sys.exit()
    else:
        print('您的输入不合法请重新输入')
        input('按任意键继续')
        continue

