#变形一，break 用在循环中(while 和 for...in 都可以用)，用于提前结束整个循环
i = 0
while i < 10:
    print(i)
    i = i + 1
    if i == 6:
        break
#0,1,2,3,4,5
#变形二，continue 用来提前结束本轮循环，然后继续判断，开始下一轮循环。
i = 0
while i < 10:
    print(i)
    i = i + 1
    if i == 6:
        continue   
#变形三
i = 0
while i < 10:
    #print(i)
    i = i + 1
    if i == 6:
        continue
    print(i)
#变形四
i = 0
while i < 10:
    i = i + 1
    if i == 6:
        continue
print(i)
#变形五
i = 0
while i < 10:
    i = i + 1
    if i == 6:
        break
print(i)
#变形六
#变形七
#变形八
#变形九等等
