class Father:
    def __init__(self, name):
        print("基类的 init ")
        self.name = name  
    def speak(self):
        print("我是父类中的 speak 方法" + self.name)
# Son继承 Father 类
class Son(Father):
    def __init__(self, name, age):
        # name 属性的初始化应该交给基类去完成, 手动调用基类的方法. 一般放在首行
        Father.__init__(self, name)  # 调动指定类的方法, 并手动绑定这个方法的 self
        print("子类的 init ")
        self.age = age
s = Son("李四", 20)
s.speak()
print(s.name)
print(s.age)


