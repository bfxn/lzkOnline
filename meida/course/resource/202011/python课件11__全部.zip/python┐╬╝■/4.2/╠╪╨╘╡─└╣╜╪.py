class Student:
    def __init__(self, name):
        self._name = name    # name 是特性了, 所以用实例变量存储特性的值的是换个变量名!!!
    @property
    def name(self):
        return self._name
    @name.setter
    def name(self, name):
        if type(name) is str and len(name) > 2:
            self._name = name
        else:
            print("你提供的值" + str(name) + "不合法!")
    @name.deleter
    def name(self):
        print("对不起, name 不允许删除")
s = Student("李四")
print(s.name)
s.name = "彩霞"
print(s.name)
s.name = "张三"
print(s.name)
del s.name

