# 创建人类
class Person:
    # 定义吃东西方法
    def eat(self):
        print("吃窝窝头。。")
    # 定义睡觉方法
    def sleep(self):
        print("睡着啦。。")
# 创建学生类
class Student(Person):
    # 子类新增方法：学习
    def study(self):
        print("学生学习啦。。。把你爸乐坏了。。。。。")
# 创建父类对象，访问父类的方法
a = Person()
a.eat()
a.sleep()
# 创建子类对象，访问父类的方法和子类的方法
b = Student();
b.eat()  # 访问父类的方法
b.sleep()  # 访问父类的方法
b.study()  # 访问子类的新增方法

