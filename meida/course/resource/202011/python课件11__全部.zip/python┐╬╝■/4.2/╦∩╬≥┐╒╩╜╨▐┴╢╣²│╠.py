def 炼丹炉(func): # func就是‘孙悟空’这个函数
  def 变身(): #*args, **kwargs就是‘孙悟空’的参数列表，这里的‘孙悟空’函数没有传参数，我们写上也不影响，建议都写上  
      print('有火眼金睛了') # 加特效，增加新功能，比如孙悟空的进了炼丹炉后，有了火眼金睛技能  
      return func() #保留原来的功能，原来孙悟空的技能，如吃桃子
  return 变身 # 炼丹成功，更强大的，有了火眼金睛技能的孙悟空出世

def 龙宫走一趟(func):
  def 你好(*args, **kwargs):
      print('有金箍棒了')
      return func(*args, **kwargs)
  return 你好

def 拜师学艺(func):
  def 师傅(*args, **kwargs):
      print('学会飞、72变了')
      return func(*args, **kwargs)
  return 师傅


@龙宫走一趟
@炼丹炉
@拜师学艺
def 孙悟空():
  print('吃桃子')

孙悟空()
# 输出
# 学会飞、72变了
# 有金箍棒了
# 有火眼金睛了
# 吃桃子


