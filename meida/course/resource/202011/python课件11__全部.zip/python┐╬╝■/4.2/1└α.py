#定义一个字符串类MyString，定义成员变量str，并同时对其赋初始值。
class MyString():
    str = "MyString"
    def output(self):
        print(self.str)
s = MyString()  #创建了一个类的对象s
s.output()      #调用


