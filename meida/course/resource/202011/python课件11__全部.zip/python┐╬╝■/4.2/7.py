class A:
    def speak(self):
        print("a 类中的方法")


class B:
    def speak(self):
        print("b 类中的方法")


def foo(obj):
    obj.speak()
    

a = A()
b = B()

foo(a)
foo(b)

