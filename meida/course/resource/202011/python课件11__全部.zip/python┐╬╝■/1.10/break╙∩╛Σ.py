i=1
for i in range(5): #此时i的范围为0到4
     #print(i)
     i+=1   
     print("-------")
     if i==3:
         break
     print(i)
