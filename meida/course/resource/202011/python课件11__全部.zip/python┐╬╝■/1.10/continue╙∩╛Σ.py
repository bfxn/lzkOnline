i = 3
for i in range(5):  #这一行i的范围为0,1,2,3,4
     i+=1             
     print("-------")
     if i==2:
         continue
     print(i)         
