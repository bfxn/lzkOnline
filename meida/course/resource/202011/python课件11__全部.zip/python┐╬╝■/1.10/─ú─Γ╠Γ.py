#以下答案仅供参考1、
name="张三"
sex="男"
age=190
address="五台山"
money=499.86
print("姓名:%s\n性别:%s\n年龄：%d\n家庭住址：%s\n收入：%f"%(name,sex,age,address,money))
print("姓名:%s\n,性别:%s\n,年龄：%d\n,家庭住址：%s\n,收入：%0.2f"%(name,sex,age,address,money))

#3、
math=10
chinese=120
python=130
if (math>90 and chinese>70) or(chinese>90 and python>70) :
   print("奖励")
#4、
a=float(input("请输入您的成绩"))
if a>=90:
   print("A")
elif a>=80:
    print("B")
elif a>=70:
    print("C")
elif a>=60:
    print("D")
else:
    print("E")
   
#5仅供参考

season="淡季"#可以写汉字，也可以写Y代表淡季，N代表旺季
types="头等舱"#同上
#season = input("请输入季节：")
#types = input("请输入座位类型：")
if season=="淡季":
    if types=="头等舱":
        print("打5折")
    else:
        print("打3折")
else:
    if types=="头等舱":
        print("打8折")
    else:
        print("打6折")
#例如：
if jijie=='淡季' and zuowei=='头等舱':
   print("打5折")
if jijie=='淡季' and zuowei=='经济舱':
   print("打3折")
   







        
